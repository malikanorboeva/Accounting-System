package exceptions;

public class AccountException extends Exception {
	
	private static final long serialVersionUID = -3250307626625866289L;

	public AccountException(String message) {
		super(message);
	}

}
