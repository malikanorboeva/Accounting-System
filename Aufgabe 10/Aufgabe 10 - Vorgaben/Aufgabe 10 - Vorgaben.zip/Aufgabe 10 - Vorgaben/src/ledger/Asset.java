package ledger;

import exceptions.AccountClosedException;
import exceptions.AmountInsufficientException;

public class Asset extends Account {

	private boolean open;
	private int delta;

	public Asset(String name) {
		super(name);
	}

	public void credit(int value) throws Exception {
		if (!open) {
			throw new AccountClosedException("Cannot credit, account is not open.");
		}
		delta -= value;
	}

	public void debit(int value) throws Exception {
		if (!open) {
			throw new AccountClosedException("Cannot debit, account is not open.");
		}
		delta += value;
	}

	public void commit() throws Exception{
		if (!open) {
			throw new AccountClosedException("Cannot commit, account is not open.");
		}
		value+=delta;
		if (value<0) {
			throw new AmountInsufficientException("Insufficient amount");
		}
		delta=0;
	}
}
