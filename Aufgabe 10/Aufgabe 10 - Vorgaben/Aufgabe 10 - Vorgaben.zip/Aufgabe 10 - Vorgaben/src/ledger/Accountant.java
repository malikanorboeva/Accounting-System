package ledger;

import exceptions.AccountException;
import exceptions.AccountNotFoundException;
import exceptions.InvalidJournalEntryException;
import exceptions.UnequalBalanceException;
import util.Pair;

import java.util.ArrayList;
import java.util.List;

public class Accountant {
	
	public void postEntry(String journalEntry) throws Exception {

		// Split the statement into debit and credit entries
		String[] entries = journalEntry.split(";");
		String[] debitEntries = entries[0].split(",");
		String[] creditEntries = entries[1].split(",");
		if (entries.length != 2) {
			throw new InvalidJournalEntryException("Invalid entry format: must contain exactly one ';' separating debits from credits");
		}

		// Create lists to store the account-value pairs and the accounts
		List<Pair<Account, Integer>> debitPairs = new ArrayList<>();
		List<Pair<Account, Integer>> creditPairs = new ArrayList<>();
		List<Account> accounts = new ArrayList<>();

		// Parse the debit entries and add them to the debitPairs list
		for (String debitEntry : debitEntries) {
			String[] parts = debitEntry.split(" ");
			String accountName = parts[0];
			int value = Integer.parseInt(parts[1]);

			Account account = AccountManager.getAccount(accountName);
			debitPairs.add(new Pair<>(account, value));
			accounts.add(account);
		}

		// Parse the credit entries and add them to the creditPairs list
		for (String creditEntry : creditEntries) {
			String[] parts = creditEntry.split(" ");
			String accountName = parts[0];
			int value = Integer.parseInt(parts[1]);

			Account account = AccountManager.getAccount(accountName);
			creditPairs.add(new Pair<>(account, value));
			accounts.add(account);
		}

		// Check that the total debit value is equal to the total credit value
		int totalDebit = 0;
		int totalCredit = 0;
		for (Pair<Account, Integer> debitPair : debitPairs) {
			totalDebit += debitPair.getValue();
		}
		for (Pair<Account, Integer> creditPair : creditPairs) {
			totalCredit += creditPair.getValue();
		}
		if (totalDebit != totalCredit) {
			throw new UnequalBalanceException("Debit and credit values do not match in statement: " + journalEntry);
		}

		// Open all accounts
		for (Account account : accounts) {
			account.open();
		}

		// Prepare the booking on each account
		for (Pair<Account, Integer> debitPair : debitPairs) {
			debitPair.getKey().debit(debitPair.getValue());
		}
		for (Pair<Account, Integer> creditPair : creditPairs) {
			creditPair.getKey().credit(creditPair.getValue());
		}

		// Commit the booking if no errors occur, otherwise abort and close all accounts
		try {
			for (Account account : accounts) {
				account.commit();
			}
		} catch (Exception e) {
			for (Account account : accounts) {
				account.abort();
				account.close();
			}
			throw new AccountException("Error occurred while committing changes, all changes were rolled back");
		}

		//check syntax and import
		
		//Ensure that debit value equals credit value
		
		//Open Accounts
		
		//Post entries
		
		//Ensure that all accounts are closed
		
	}
}
